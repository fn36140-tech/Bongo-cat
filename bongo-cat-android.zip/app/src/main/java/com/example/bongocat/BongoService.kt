package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import kotlin.math.abs

class BongoService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var view: ImageView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val frames = ArrayList<Drawable>()
    private val idle = 4
    private var idx = idle
    private var last = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (view == null) createOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) hit()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) hit()
        return false
    }

    override fun onInterrupt() {}

    private fun createOverlay() {
        for (i in 0 until 55) {
            val id = resources.getIdentifier("f%02d".format(i), "drawable", packageName)
            frames.add(resources.getDrawable(id, null))
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val width = (240 * resources.displayMetrics.density).toInt()
        val height = width * 206 / 300
        val params = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 300

        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        iv.setImageDrawable(frames[idle])

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        iv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(iv, params)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) hit()
            }
            true
        }
        wm.addView(iv, params)
        view = iv
    }

    private fun hit() {
        val iv = view ?: return
        val now = SystemClock.uptimeMillis()
        if (now - last < 40) return
        last = now
        do { idx = (idx + 1) % frames.size } while (idx == idle)
        iv.setImageDrawable(frames[idx])
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ iv.setImageDrawable(frames[idle]) }, 180)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        view?.let { wm.removeView(it) }
        view = null
        super.onDestroy()
    }
}
