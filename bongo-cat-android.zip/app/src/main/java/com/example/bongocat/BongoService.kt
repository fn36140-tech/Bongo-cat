package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs

class BongoService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var cat: ImageView
    private var root: FrameLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var idle: Drawable
    private val typing = ArrayList<Drawable>()
    private val mouse = ArrayList<Drawable>()
    private var tIdx = 0
    private var mIdx = 0
    private var lastKey = 0L
    private var lastMouse = 0L
    private var lastLoose = 0L
    private var sens = 1
    private var widthDp = 240
    private var aspect = 0.5f
    private var density = 1f

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == "sens") {
            sens = p.getInt("sens", 1)
        } else if (key == "w") {
            widthDp = p.getInt("w", 240)
            relayout()
        } else if (key == "skin") {
            if (root != null) {
                loadSkin(p.getInt("skin", 0))
                cat.setImageDrawable(idle)
                relayout()
            }
        }
    }

    private fun relayout() {
        if (root != null) {
            computeSize()
            wm.updateViewLayout(root, params)
        }
    }

    private var mx = MousePos.REST_X
    private var my = MousePos.REST_Y
    private var jitter = 1f
    private var lastSX = 0
    private var lastPX = 0f
    private var lastPY = 0f
    private var havePointer = false
    private var lastSY = 0

    private val resetCat = Runnable {
        cat.setImageDrawable(idle)
        mx = MousePos.REST_X
        my = MousePos.REST_Y
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val info = serviceInfo
                info.motionEventSources =
                    InputDevice.SOURCE_MOUSE or InputDevice.SOURCE_MOUSE_RELATIVE
                serviceInfo = info
            } catch (t: Throwable) {
            }
        }
        if (root == null) createOverlay()
    }

    override fun onMotionEvent(event: MotionEvent) {
        if (root == null) return
        val relative = (event.source and InputDevice.SOURCE_MOUSE_RELATIVE) ==
            InputDevice.SOURCE_MOUSE_RELATIVE
        var dx = 0f
        var dy = 0f
        if (relative) {
            dx = event.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
            dy = event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
        } else {
            if (havePointer) {
                dx = event.rawX - lastPX
                dy = event.rawY - lastPY
            }
            lastPX = event.rawX
            lastPY = event.rawY
            havePointer = true
        }
        val a = event.actionMasked
        if (a == MotionEvent.ACTION_BUTTON_PRESS || a == MotionEvent.ACTION_DOWN) {
            mouseHit()
        } else if (dx != 0f || dy != 0f) {
            mouseMove(dx / 6f, dy / 6f)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (root == null || event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> typeHit()
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> scrolled(event)
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SELECTED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> mouseHit()
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> if (sens == 1) mouseHit()
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> if (sens == 1) {
                val now = SystemClock.uptimeMillis()
                if (now - lastLoose >= 120) {
                    lastLoose = now
                    val text = event.contentChangeTypes and AccessibilityEvent.CONTENT_CHANGE_TYPE_TEXT
                    if (text != 0) typeHit() else mouseHit()
                }
            }
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (root != null && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) typeHit()
        return false
    }

    override fun onInterrupt() {}

    private fun load(prefix: String, into: ArrayList<Drawable>) {
        var i = 0
        while (true) {
            val id = resources.getIdentifier("%s%02d".format(prefix, i), "drawable", packageName)
            if (id == 0) break
            into.add(resources.getDrawable(id, null))
            i++
        }
    }

    private fun loadSkin(skin: Int) {
        typing.clear()
        mouse.clear()
        tIdx = 0
        mIdx = 0
        if (skin == 1) {
            // gato antigo
            load("o", typing)
            idle = typing.removeAt(4)
            aspect = 206f / 300f
        } else if (skin == 2 || skin == 3) {
            // gatos do plugin (teclado / osu)
            val pre = if (skin == 2) "k" else "s"
            idle = resources.getDrawable(
                resources.getIdentifier(pre + "idle", "drawable", packageName), null
            )
            load(pre, typing)
            aspect = 354f / 612f
        } else {
            // gato novo, com mouse
            idle = resources.getDrawable(
                resources.getIdentifier("idle", "drawable", packageName), null
            )
            load("t", typing)
            load("d", mouse)
            aspect = 0.5f
        }
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)
        widthDp = prefs.getInt("w", 240)
        sens = prefs.getInt("sens", 1)
        loadSkin(prefs.getInt("skin", 0))
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        params = WindowManager.LayoutParams(
            10, 10,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 300

        val r = FrameLayout(this)
        cat = ImageView(this)
        cat.scaleType = ImageView.ScaleType.FIT_XY
        cat.setImageDrawable(idle)
        r.addView(cat, FrameLayout.LayoutParams(10, 10))

        var startX = 0
        var startY = 0
        var touchX = 0f
        var lastX = 0f
        var lastY = 0f
        var touchY = 0f
        var moved = false
        cat.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    lastX = e.rawX; lastY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    val ddx = e.rawX - lastX
                    val ddy = e.rawY - lastY
                    lastX = e.rawX
                    lastY = e.rawY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(r, params)
                        mouseMove(ddx / 8f, ddy / 8f)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) typeHit()
            }
            true
        }

        root = r
        computeSize()
        wm.addView(r, params)
    }

    private fun computeSize() {
        val w = (widthDp * density).toInt()
        val h = (w * aspect).toInt()
        params.width = w
        params.height = h
        cat.layoutParams = FrameLayout.LayoutParams(w, h)
    }

    private fun typeHit() {
        if (root == null || typing.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastKey < 10) return
        lastKey = now
        tIdx = (tIdx + 1) % typing.size
        cat.setImageDrawable(typing[tIdx])
        handler.removeCallbacks(resetCat)
        handler.postDelayed(resetCat, 130)
    }

    private fun mouseHit() {
        jitter = -jitter
        mouseMove(3f * jitter, 0f)
    }

    private fun scrolled(e: AccessibilityEvent) {
        var dx = -e.scrollDeltaX.toFloat()
        var dy = -e.scrollDeltaY.toFloat()
        if (e.scrollDeltaX == 0 && e.scrollDeltaY == 0) {
            if (e.scrollX >= 0) dx = -(e.scrollX - lastSX).toFloat()
            if (e.scrollY >= 0) dy = -(e.scrollY - lastSY).toFloat()
        }
        lastSX = e.scrollX
        lastSY = e.scrollY
        if (dx == 0f && dy == 0f) {
            mouseHit()
            return
        }
        mouseMove((dx / 40f).coerceIn(-4f, 4f), (dy / 40f).coerceIn(-4f, 4f))
    }

    private fun mouseMove(dx: Float, dy: Float) {
        if (root == null) return
        if (mouse.isEmpty()) {
            typeHit()
            return
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastMouse < 16) return
        if (now - lastKey < 80) return
        lastMouse = now
        mx = (mx + dx).coerceIn(MousePos.MIN_X, MousePos.MAX_X)
        my = (my + dy).coerceIn(MousePos.MIN_Y, MousePos.MAX_Y)
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in MousePos.X.indices) {
            val ex = MousePos.X[i] - mx
            val ey = MousePos.Y[i] - my
            val dist = ex * ex + ey * ey
            if (dist < bd) {
                bd = dist
                best = i
            }
        }
        if (best < mouse.size) cat.setImageDrawable(mouse[best])
        handler.removeCallbacks(resetCat)
        handler.postDelayed(resetCat, 350)
    }

    override fun onDestroy() {
        getSharedPreferences("bongo", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        handler.removeCallbacksAndMessages(null)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
