package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs

class BongoService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var cat: ImageView
    private var root: FrameLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private val frames = ArrayList<Drawable>()
    private val idle = 20
    private var idx = idle
    private var last = 0L
    private var widthDp = 240
    private var density = 1f

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == "w") {
            widthDp = p.getInt("w", 240)
            if (root != null) {
                computeSize()
                wm.updateViewLayout(root, params)
            }
        }
    }

    private val resetCat = Runnable { cat.setImageDrawable(frames[idle]) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (root == null) createOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (root == null) return
        when (event?.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED,
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> hit()
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (root != null && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) hit()
        return false
    }

    override fun onInterrupt() {}

    private fun createOverlay() {
        var i = 0
        while (true) {
            val id = resources.getIdentifier("f%02d".format(i), "drawable", packageName)
            if (id == 0) break
            frames.add(resources.getDrawable(id, null))
            i++
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)
        widthDp = prefs.getInt("w", 240)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        params = WindowManager.LayoutParams(
            10, 10,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 300

        val r = FrameLayout(this)
        cat = ImageView(this)
        cat.scaleType = ImageView.ScaleType.FIT_XY
        cat.setImageDrawable(frames[idle])
        r.addView(cat, FrameLayout.LayoutParams(10, 10))

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        cat.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(r, params)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) hit()
            }
            true
        }

        root = r
        computeSize()
        wm.addView(r, params)
    }

    private fun computeSize() {
        val w = (widthDp * density).toInt()
        val h = w / 2
        params.width = w
        params.height = h
        cat.layoutParams = FrameLayout.LayoutParams(w, h)
    }

    private fun hit() {
        if (root == null) return
        val now = SystemClock.uptimeMillis()
        if (now - last < 25) return
        last = now
        idx = (idx + 1) % frames.size
        if (idx == idle) idx = (idx + 1) % frames.size
        cat.setImageDrawable(frames[idx])
        handler.removeCallbacks(resetCat)
        handler.postDelayed(resetCat, 220)
    }

    override fun onDestroy() {
        getSharedPreferences("bongo", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        handler.removeCallbacksAndMessages(null)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
