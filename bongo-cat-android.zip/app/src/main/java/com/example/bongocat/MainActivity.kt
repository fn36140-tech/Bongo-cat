package com.example.bongocat

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(48, 48, 48, 48)

        val title = TextView(this)
        title.text = "Bongo Cat flutuante"
        title.textSize = 24f
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "Toque no gato para ele bater. Arraste para mover."
        hint.gravity = Gravity.CENTER

        val start = Button(this)
        start.text = "Iniciar gato"
        start.setOnClickListener { startCat() }

        val stop = Button(this)
        stop.text = "Parar gato"
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }

        root.addView(title)
        root.addView(hint)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun startCat() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita \"Sobrepor a outros apps\" e volte", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
