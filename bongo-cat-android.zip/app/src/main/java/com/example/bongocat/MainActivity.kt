package com.example.bongocat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(48, 48, 48, 48)

        val title = TextView(this)
        title.text = "Bongo Cat flutuante"
        title.textSize = 24f
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "1. Toque no botao abaixo.\n" +
            "2. Em Apps instalados / Servicos baixados, toque em Bongo Cat e ative.\n" +
            "3. O gato aparece e bate a pata quando voce digita em qualquer app.\n" +
            "Arraste o gato para mover. O app nao le o que voce digita.\n" +
            "Para desligar, desative o servico na mesma tela."
        hint.setPadding(0, 16, 0, 16)

        val open = Button(this)
        open.text = "Abrir ajustes de acessibilidade"
        open.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val sizeLabel = TextView(this)
        sizeLabel.gravity = Gravity.CENTER
        sizeLabel.textSize = 18f
        sizeLabel.setPadding(0, 24, 0, 8)

        fun refresh() {
            sizeLabel.text = "Tamanho do gato: " + prefs.getInt("w", 240)
        }
        fun change(delta: Int) {
            val v = (prefs.getInt("w", 240) + delta).coerceIn(100, 420)
            prefs.edit().putInt("w", v).apply()
            refresh()
        }
        refresh()

        val minus = Button(this)
        minus.text = "Diminuir  -"
        minus.setOnClickListener { change(-30) }
        val plus = Button(this)
        plus.text = "Aumentar  +"
        plus.setOnClickListener { change(30) }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.addView(minus)
        row.addView(plus)

        val skinLabel = TextView(this)
        skinLabel.gravity = Gravity.CENTER
        skinLabel.textSize = 18f
        skinLabel.setPadding(0, 24, 0, 8)
        fun refreshSkin() {
            val names = arrayOf("novo (com mouse)", "antigo", "plugin teclado", "plugin osu")
            skinLabel.text = "Gato atual: " + names[prefs.getInt("skin", 0).coerceIn(0, 3)]
        }
        refreshSkin()
        val skinNew = Button(this)
        skinNew.text = "Gato novo"
        skinNew.setOnClickListener {
            prefs.edit().putInt("skin", 0).apply()
            refreshSkin()
        }
        val skinOld = Button(this)
        skinOld.text = "Gato antigo"
        skinOld.setOnClickListener {
            prefs.edit().putInt("skin", 1).apply()
            refreshSkin()
        }
        val skinRow = LinearLayout(this)
        skinRow.orientation = LinearLayout.HORIZONTAL
        skinRow.gravity = Gravity.CENTER
        skinRow.addView(skinNew)
        skinRow.addView(skinOld)
        val skinP1 = Button(this)
        skinP1.text = "Plugin teclado"
        skinP1.setOnClickListener {
            prefs.edit().putInt("skin", 2).apply()
            refreshSkin()
        }
        val skinP2 = Button(this)
        skinP2.text = "Plugin osu"
        skinP2.setOnClickListener {
            prefs.edit().putInt("skin", 3).apply()
            refreshSkin()
        }
        val skinRow2 = LinearLayout(this)
        skinRow2.orientation = LinearLayout.HORIZONTAL
        skinRow2.gravity = Gravity.CENTER
        skinRow2.addView(skinP1)
        skinRow2.addView(skinP2)

        val sensLabel = TextView(this)
        sensLabel.gravity = Gravity.CENTER
        sensLabel.textSize = 18f
        sensLabel.setPadding(0, 24, 0, 8)
        fun refreshSens() {
            sensLabel.text = "Sensibilidade: " +
                (if (prefs.getInt("sens", 1) == 1) "alta" else "normal")
        }
        refreshSens()
        val sensNormal = Button(this)
        sensNormal.text = "Normal"
        sensNormal.setOnClickListener {
            prefs.edit().putInt("sens", 0).apply()
            refreshSens()
        }
        val sensHigh = Button(this)
        sensHigh.text = "Alta"
        sensHigh.setOnClickListener {
            prefs.edit().putInt("sens", 1).apply()
            refreshSens()
        }
        val sensRow = LinearLayout(this)
        sensRow.orientation = LinearLayout.HORIZONTAL
        sensRow.gravity = Gravity.CENTER
        sensRow.addView(sensNormal)
        sensRow.addView(sensHigh)

        root.addView(title)
        root.addView(hint)
        root.addView(open)
        root.addView(sizeLabel)
        root.addView(row)
        root.addView(skinLabel)
        root.addView(skinRow)
        root.addView(skinRow2)
        root.addView(sensLabel)
        root.addView(sensRow)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }
}
