package com.example.bongocat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(48, 48, 48, 48)

        val title = TextView(this)
        title.text = "Bongo Cat flutuante"
        title.textSize = 24f
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "1. Toque no botao abaixo.\n" +
            "2. Em Apps instalados / Servicos baixados, toque em Bongo Cat e ative.\n" +
            "3. O gato aparece e bate a pata quando voce digita em qualquer app.\n" +
            "Arraste o gato para mover. O app nao le o que voce digita.\n" +
            "Para desligar, desative o servico na mesma tela."
        hint.setPadding(0, 32, 0, 32)

        val open = Button(this)
        open.text = "Abrir ajustes de acessibilidade"
        open.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val sizeLabel = TextView(this)
        sizeLabel.gravity = Gravity.CENTER
        sizeLabel.textSize = 18f
        sizeLabel.setPadding(0, 48, 0, 8)

        fun refresh() {
            sizeLabel.text = "Tamanho do gato: " + prefs.getInt("w", 240)
        }
        fun change(delta: Int) {
            val v = (prefs.getInt("w", 240) + delta).coerceIn(100, 420)
            prefs.edit().putInt("w", v).apply()
            refresh()
        }
        refresh()

        val minus = Button(this)
        minus.text = "Diminuir  -"
        minus.setOnClickListener { change(-30) }
        val plus = Button(this)
        plus.text = "Aumentar  +"
        plus.setOnClickListener { change(30) }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.addView(minus)
        row.addView(plus)

        root.addView(title)
        root.addView(hint)
        root.addView(open)
        root.addView(sizeLabel)
        root.addView(row)
        setContentView(root)
    }
}
