package com.example.bongocat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(48, 48, 48, 48)

        val title = TextView(this)
        title.text = "Bongo Cat flutuante"
        title.textSize = 24f
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "1. Toque no botao abaixo.\n" +
            "2. Em Apps instalados / Servicos baixados, toque em Bongo Cat e ative.\n" +
            "3. O gato aparece e bate a pata quando voce digita em qualquer app.\n" +
            "Arraste o gato para mover. O app nao le o que voce digita."
        hint.setPadding(0, 16, 0, 16)

        val open = Button(this)
        open.text = "Abrir ajustes de acessibilidade"
        open.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // tamanho
        val sizeLabel = TextView(this)
        sizeLabel.gravity = Gravity.CENTER
        sizeLabel.textSize = 18f
        sizeLabel.setPadding(0, 24, 0, 8)
        fun refreshSize() {
            sizeLabel.text = "Tamanho do gato: " + prefs.getInt("w", 240)
        }
        fun change(delta: Int) {
            val v = (prefs.getInt("w", 240) + delta).coerceIn(100, 420)
            prefs.edit().putInt("w", v).apply()
            refreshSize()
        }
        refreshSize()
        val minus = Button(this)
        minus.text = "Diminuir  -"
        minus.setOnClickListener { change(-30) }
        val plus = Button(this)
        plus.text = "Aumentar  +"
        plus.setOnClickListener { change(30) }
        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL
        sizeRow.gravity = Gravity.CENTER
        sizeRow.addView(minus)
        sizeRow.addView(plus)

        // escolher gato
        val skinLabel = TextView(this)
        skinLabel.text = "Escolher gato:"
        skinLabel.gravity = Gravity.CENTER
        skinLabel.textSize = 18f
        skinLabel.setPadding(0, 24, 0, 8)
        val names = arrayOf(
            "Gato novo (com mouse)",
            "Gato antigo",
            "Plugin teclado",
            "Plugin osu",
            "Mac padrao",
            "Mac teclado",
            "Mac gamepad"
        )
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.setSelection(prefs.getInt("skin", 0).coerceIn(0, names.size - 1))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("skin", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // sensibilidade
        val sensLabel = TextView(this)
        sensLabel.gravity = Gravity.CENTER
        sensLabel.textSize = 18f
        sensLabel.setPadding(0, 24, 0, 8)
        fun refreshSens() {
            sensLabel.text = "Sensibilidade: " +
                (if (prefs.getInt("sens", 1) == 1) "alta" else "normal")
        }
        refreshSens()
        val sensNormal = Button(this)
        sensNormal.text = "Normal"
        sensNormal.setOnClickListener {
            prefs.edit().putInt("sens", 0).apply()
            refreshSens()
        }
        val sensHigh = Button(this)
        sensHigh.text = "Alta"
        sensHigh.setOnClickListener {
            prefs.edit().putInt("sens", 1).apply()
            refreshSens()
        }
        val sensRow = LinearLayout(this)
        sensRow.orientation = LinearLayout.HORIZONTAL
        sensRow.gravity = Gravity.CENTER
        sensRow.addView(sensNormal)
        sensRow.addView(sensHigh)

        root.addView(title)
        root.addView(hint)
        root.addView(open)
        root.addView(sizeLabel)
        root.addView(sizeRow)
        root.addView(skinLabel)
        root.addView(spinner)
        root.addView(sensLabel)
        root.addView(sensRow)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }
}
