package com.example.bongocat

object MousePos {
    val X = floatArrayOf(59.6f, 60.2f, 60.4f, 60.5f, 60.6f, 61.3f, 61.4f, 62.9f, 63.1f, 63.4f, 63.5f, 64.2f, 64.3f, 64.4f, 65.3f, 65.4f, 65.6f, 66.9f, 67.3f, 67.3f, 67.6f, 67.7f, 67.9f, 67.9f, 68.3f, 68.6f, 68.8f, 68.9f, 69.6f, 70.0f)
    val Y = floatArrayOf(131.4f, 131.6f, 131.1f, 130.5f, 131.1f, 130.2f, 131.6f, 131.0f, 129.8f, 130.1f, 131.2f, 131.5f, 130.9f, 129.6f, 128.2f, 128.6f, 132.4f, 127.2f, 131.1f, 127.9f, 131.1f, 130.2f, 127.3f, 128.1f, 130.6f, 127.1f, 127.8f, 130.0f, 129.4f, 128.9f)
    const val REST_X = 59.6f
    const val REST_Y = 131.4f
    val MIN_X = X.min()
    val MAX_X = X.max()
    val MIN_Y = Y.min()
    val MAX_Y = Y.max()
}
